#!/bin/bash

# check sudo
if [[ $EUID -ne 0 ]]; then
  echo "$0 must be run as root. "
  exit 2
fi

# -y flag
y_flag=true
while getopts y flag
do
  case "${flag}" in
    y) y_flag=false;
  esac
done

# EULA
if [ "$y_flag" = true ]; then
  echo -n 'Do you accept the End User License Agreement? https://app.gala.games/terms-and-conditions ([Y]es/[N]o): '
  read agree
  case $agree in
    y | Y | Yes | yes)
      # contiune
      ;;
    *)
      echo "Exit installation"
      exit 1
      ;;
  esac
fi

# Check if docker is installed and check installed version
function versionToNum { echo "$@" | awk -F. '{ printf("%d%03d%03d%03d\n", $1,$2,$3,$4); }'; }
if [ -x "$(command -v docker)" ]; then
  MIN_DOCKER_VERSION="20.10.12"
  SERVER_VERSION=$(docker version -f "{{.Server.Version}}")
  echo "Docker version check..."
  if [ $(versionToNum $SERVER_VERSION) -ge $(versionToNum $MIN_DOCKER_VERSION) ]; then
    echo "Installed docker version $SERVER_VERSION >= $MIN_DOCKER_VERSION "
  else
    echo "Installed docker version $SERVER_VERSION is less than $MIN_DOCKER_VERSION. Install cannot continue."
    echo "Please install docker $MIN_DOCKER_VERSION or later "
    exit 1
  fi
else
  echo "Docker is not installed. "
  echo "Please follow the instuction here https://docs.docker.com/engine/install/ubuntu to install docker. "
  exit 1
fi

parent_dir=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

# Install kubectl
echo "Install kubectl..."
install -o root -g root -m 0755 "$parent_dir/kubectl/kubectl" /usr/local/bin/kubectl

# Users should prefer to use the gala-node upgrade command, but try to accommodate the install script being run multiple times.
# Stop and uninstall any existing gala-node service
if [ -x "$(command -v gala-node)" ]; then
  echo "Found existing gala-node"
  if gala-node service --help &> /dev/null; then
    echo "Existing gala-node has service support"
    SERVICE_STATUS=$(gala-node service status)
    if [[ $SERVICE_STATUS =~ "Running" ]]; then
      echo "Stopping gala-node service..."
      gala-node service stop
      echo "Uninstalling gala-node service..."
      gala-node service uninstall
    elif [[ $SERVICE_STATUS =~ "Stopped" ]]; then
      echo "Uninstalling gala-node service..."
      gala-node service uninstall
    else
      echo "gala-node service is not installed"
    fi
  else
    echo "Current gala-node doesn't have service support"
  fi
  echo "Removing any existing cluster..."
  # Check if "--local" flag is supported
  if gala-node remove --help | grep -q -- '--local'; then
    echo "Using local remove mode"
    gala-node remove --local
  else
    echo "Using legacy remove mode"
    gala-node remove
  fi  
  # Check if bash autocomplete is installed and remove it before installing the new one.
  if gala-node --help | grep -q autocomplete; then
    echo "Removing existing autocomplete script"
    gala-node autocomplete bash uninstall
  else 
    echo "Autocomplete is not supported by the current executable"
  fi
else
  echo "gala-node is not already installed"
fi

# Install gala-node 
parent_dir=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )
install -o root -g root -m 0755 "$parent_dir/gala-node" /usr/local/bin/gala-node

# Install bash autocompletion if it is supported
if [ -f /etc/bash_completion ] && ! shopt -oq posix; then
  echo "Installing bash completion"
  /usr/local/bin/gala-node autocomplete bash install
fi

# Install gala-node service
echo "Installing gala-node service..."
/usr/local/bin/gala-node service install

# Start the gala-node service
echo "Starting gala-node service..."
/usr/local/bin/gala-node service start

echo "Gala Node installation complete. "