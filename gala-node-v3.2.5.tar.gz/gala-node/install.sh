#!/bin/bash

# check sudo
if [[ $EUID -ne 0 ]]; then
  echo "$0 must be run as root. "
  exit 2
fi

# -y flag
y_flag=true
while getopts y flag
do
  case "${flag}" in
    y) y_flag=false;
  esac
done

# EULA
if [ "$y_flag" = true ]; then
  echo -n 'Do you accept the End User License Agreement? https://app.gala.games/terms-and-conditions ([Y]es/[N]o): '
  read agree
  case $agree in
    y | Y | Yes | yes)
      # contiune
      ;;
    *)
      echo "Exit installation"
      exit 1
      ;;
  esac
fi

# Check if docker is installed and check installed version
function versionToNum { echo "$@" | awk -F. '{ printf("%d%03d%03d%03d\n", $1,$2,$3,$4); }'; }
if [ -x "$(command -v docker)" ]; then
  MIN_DOCKER_VERSION="20.10.12"
  SERVER_VERSION=$(docker version -f "{{.Server.Version}}")
  echo "Docker version check..."
  if [ $(versionToNum $SERVER_VERSION) -ge $(versionToNum $MIN_DOCKER_VERSION) ]; then
    echo "Installed docker version $SERVER_VERSION >= $MIN_DOCKER_VERSION "
  else
    echo "Installed docker version $SERVER_VERSION is less than $MIN_DOCKER_VERSION. Install cannot continue."
    echo "Please install docker $MIN_DOCKER_VERSION or later "
    exit 1
  fi
else
  echo "Docker is not installed. "
  echo "Please follow the instuction here https://docs.docker.com/engine/install/ubuntu to install docker. "
  exit 1
fi

parent_dir=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

# Install kubectl
echo "Install kubectl..."
install -o root -g root -m 0755 "$parent_dir/kubectl/kubectl" /usr/local/bin/kubectl

# Install gala-node 
parent_dir=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )
install -o root -g root -m 0755 "$parent_dir/gala-node" /usr/local/bin/gala-node

echo "Gala Node installation complete. "
